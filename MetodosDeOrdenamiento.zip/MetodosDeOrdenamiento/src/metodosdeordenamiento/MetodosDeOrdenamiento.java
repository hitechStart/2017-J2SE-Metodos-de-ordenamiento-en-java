
package metodosdeordenamiento;

import java.util.Calendar;


public class MetodosDeOrdenamiento {

	
	/*************BURBUJEO*******************/
	public void burbuja(int vector[])
	{
		int aux=0;
		
		
		for(int i=0;i<vector.length;i++)
		{
			for(int j=0;j<vector.length-1;j++)
			{
				if(vector[j]>vector[j+1])
				{
					aux=vector[i];
					vector[i]=vector[j];
					vector[j]=aux;
				}
			}
			
		}
		
	}
	
	
	
	/*************SELECCION*******************/
	
	public void seleccion(int vector[])
	{
		for (int i = 0; i < vector.length - 1; i++)
        {
                int min = i;
                for (int j = i + 1; j < vector.length; j++)
                {
                        if (vector[j] < vector[min])
                        {
                                min = j;
                        }
                }
                if (i != min) 
                {
                        int aux= vector[i];
                        vector[i] = vector[min];
                        vector[min] = aux;
                }
        }
	}
	
	/*************INSERCION*******************/
	public void insercion(int vector[])
	{
	      for (int i=1; i<vector.length; i++) {
	          int aux = vector[i];
	          int j;
	          for (j=i-1; j>=0 && vector[j]>aux; j--)
	        	  vector[j+1] = vector[j];
	          vector[j+1] = aux;
	       }
	}
	
	/*************SHELL*******************/
	public void shell(int vector[])
	{
		  for ( int increment = vector.length / 2;
          increment > 0;
          increment = (increment == 2 ? 1 : (int) Math.round(increment / 2.2))) {
        for (int i = increment; i < vector.length; i++) {
            for (int j = i; j >= increment && vector[j - increment] > vector[j]; j -= increment) {
                int temp = vector[j];
                vector[j] = vector[j - increment];
                vector[j - increment] = temp;
            }
        }
    }
	}
		
	/******************QUICKSORT*************/
	
	void ordenarQuicksort(int[] vector, int primero, int ultimo){
        int i=primero, j=ultimo;
        int pivote=vector[(primero + ultimo) / 2];
        int auxiliar;
 
        do{
                while(vector[i]<pivote) i++;                  
                while(vector[j]>pivote) j--;
 
                if (i<=j){
                        auxiliar=vector[j];
                        vector[j]=vector[i];
                        vector[i]=auxiliar;
                        i++;
                        j--;
                }
 
        } while (i<=j);
 
        if(primero<j) ordenarQuicksort(vector,primero, j);
        if(ultimo>i) ordenarQuicksort(vector,i, ultimo);
    }
	
	
	
	
	/*GENERADORES DE VALORES*/
	public static void numerosOrdenados (int vector[])
	{
		for(int i=0;i<vector.length;i++)
			vector[i]=i+1;
	}
	
	public static void numerosOrdenInverso( int vector[])
	{
		for(int i=0;i<vector.length;i++)
			vector[i]=vector.length-i;
	}
	
	public static void numerosDesordenados( int vector[])
	{
		for(int i=0;i<vector.length;i++)
			vector[i]=(int) (Math.random()*100+Math.random()*100);
	}
	
	
	public static void main(String argv[])
	{
		int vectorOrdenado[]=new int[200000];
		int vectorOrdenInverso[]=new int[200000];
		int vectorDesordenado[]=new int[200000];
		MetodosDeOrdenamiento obj=new MetodosDeOrdenamiento();
		
		/*********inicializao los vectores*************/
		MetodosDeOrdenamiento.numerosOrdenados(vectorOrdenado);
		MetodosDeOrdenamiento.numerosOrdenInverso(vectorOrdenInverso);
		MetodosDeOrdenamiento.numerosDesordenados(vectorDesordenado);
		
		Calendar inicio,fin;	
		
		System.out.println("DATOS ORDENADOS");
		
		inicio=Calendar.getInstance();
		obj.burbuja(vectorOrdenado);
		fin=Calendar.getInstance();
		System.out.print("Burbujeo: ");
		System.out.println(fin.getTimeInMillis()-inicio.getTimeInMillis());
		
		inicio=Calendar.getInstance();
		obj.seleccion(vectorOrdenado);
		fin=Calendar.getInstance();
		System.out.print("seleccion: ");
		System.out.println(fin.getTimeInMillis()-inicio.getTimeInMillis());
		
		
		inicio=Calendar.getInstance();
		obj.insercion(vectorOrdenado);
		fin=Calendar.getInstance();
		System.out.print("Insercion: ");
		System.out.println(fin.getTimeInMillis()-inicio.getTimeInMillis());
		
		inicio=Calendar.getInstance();
		obj.shell(vectorOrdenado);
		fin=Calendar.getInstance();
		System.out.print("Shell: ");
		System.out.println(fin.getTimeInMillis()-inicio.getTimeInMillis());
		
		
		inicio=Calendar.getInstance();
		obj.ordenarQuicksort(vectorOrdenado,0,vectorOrdenado.length-1);
		fin=Calendar.getInstance();
		System.out.print("Quicksort: ");
		System.out.println(fin.getTimeInMillis()-inicio.getTimeInMillis());
			
		
	//////////////////////////////////////////////////////////////////////////	
		System.out.println("DATOS ORDEN INVERSO");
		
		inicio=Calendar.getInstance();
		obj.burbuja(vectorOrdenInverso);
		fin=Calendar.getInstance();
		System.out.print("Burbujeo: ");
		System.out.println(fin.getTimeInMillis()-inicio.getTimeInMillis());
		
		inicio=Calendar.getInstance();
		obj.seleccion(vectorOrdenInverso);
		fin=Calendar.getInstance();
		System.out.print("seleccion: ");
		System.out.println(fin.getTimeInMillis()-inicio.getTimeInMillis());
		
		
		inicio=Calendar.getInstance();
		obj.insercion(vectorOrdenInverso);
		fin=Calendar.getInstance();
		System.out.print("Insercion: ");
		System.out.println(fin.getTimeInMillis()-inicio.getTimeInMillis());
		
		inicio=Calendar.getInstance();
		obj.shell(vectorOrdenInverso);
		fin=Calendar.getInstance();
		System.out.print("Shell: ");
		System.out.println(fin.getTimeInMillis()-inicio.getTimeInMillis());
		
		inicio=Calendar.getInstance();
		obj.ordenarQuicksort(vectorOrdenInverso,0,vectorOrdenInverso.length-1);
		fin=Calendar.getInstance();
		System.out.print("Quicksort: ");
		System.out.println(fin.getTimeInMillis()-inicio.getTimeInMillis());
		
		
////////////////////////////////////////////////////////////////////////////		
		System.out.println("DATOS DESORDENADO");
		inicio=Calendar.getInstance();
		obj.burbuja(vectorDesordenado);
		fin=Calendar.getInstance();
		System.out.print("Burbujeo: ");
		System.out.println(fin.getTimeInMillis()-inicio.getTimeInMillis());
		
		inicio=Calendar.getInstance();
		obj.seleccion(vectorDesordenado);
		fin=Calendar.getInstance();
		System.out.print("seleccion: ");
		System.out.println(fin.getTimeInMillis()-inicio.getTimeInMillis());
		
		
		inicio=Calendar.getInstance();
		obj.insercion(vectorDesordenado);
		fin=Calendar.getInstance();
		System.out.print("Insercion: ");
		System.out.println(fin.getTimeInMillis()-inicio.getTimeInMillis());
		
		inicio=Calendar.getInstance();
		obj.shell(vectorDesordenado);
		fin=Calendar.getInstance();
		System.out.print("Shell: ");
		System.out.println(fin.getTimeInMillis()-inicio.getTimeInMillis());
		
		
		inicio=Calendar.getInstance();
		obj.ordenarQuicksort(vectorDesordenado,0,vectorDesordenado.length-1);
		fin=Calendar.getInstance();
		System.out.print("ordenarQuicksort: ");
		System.out.println(fin.getTimeInMillis()-inicio.getTimeInMillis());

      
    }
    
}
